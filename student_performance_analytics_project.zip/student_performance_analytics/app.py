import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(page_title="Student Performance Analytics", page_icon="📊", layout="wide")

st.title("📊 Student Performance Analytics")
st.caption("A beginner-friendly data analytics portfolio project | Uses synthetic demo data")

@st.cache_data
def load_data(uploaded_file=None):
    if uploaded_file is not None:
        data = pd.read_csv(uploaded_file)
    else:
        data = pd.read_csv("student_performance_demo.csv")
    required = {"student_id", "department", "subject", "attendance_pct",
                "study_hours_per_day", "assignment_score", "exam_score"}
    missing = required - set(data.columns)
    if missing:
        st.error("Missing required columns: " + ", ".join(sorted(missing)))
        st.stop()
    return data

uploaded = st.sidebar.file_uploader("Upload your own CSV (optional)", type=["csv"])
data = load_data(uploaded)

st.sidebar.header("Filters")
departments = sorted(data["department"].dropna().unique().tolist())
subjects = sorted(data["subject"].dropna().unique().tolist())
selected_departments = st.sidebar.multiselect("Department", departments, default=departments)
selected_subjects = st.sidebar.multiselect("Subject", subjects, default=subjects)
attendance_min = st.sidebar.slider("Minimum attendance (%)", 0, 100, 0)

filtered = data[
    data["department"].isin(selected_departments)
    & data["subject"].isin(selected_subjects)
    & (data["attendance_pct"] >= attendance_min)
].copy()

if filtered.empty:
    st.warning("No records match these filters. Change the filters to view results.")
    st.stop()

pass_rate = (filtered["exam_score"] >= 40).mean() * 100
avg_score = filtered["exam_score"].mean()
avg_attendance = filtered["attendance_pct"].mean()
avg_study = filtered["study_hours_per_day"].mean()

c1, c2, c3, c4 = st.columns(4)
c1.metric("Students in view", f"{len(filtered):,}")
c2.metric("Average exam score", f"{avg_score:.1f}/100")
c3.metric("Pass rate", f"{pass_rate:.1f}%")
c4.metric("Average attendance", f"{avg_attendance:.1f}%")

st.divider()
left, right = st.columns(2)
with left:
    st.subheader("Exam score distribution")
    fig = px.histogram(filtered, x="exam_score", nbins=15, title="How scores are distributed",
                       labels={"exam_score": "Exam score"})
    st.plotly_chart(fig, use_container_width=True)
with right:
    st.subheader("Average score by subject")
    subject_avg = filtered.groupby("subject", as_index=False)["exam_score"].mean().sort_values("exam_score", ascending=False)
    fig = px.bar(subject_avg, x="subject", y="exam_score", color="exam_score",
                 labels={"subject": "Subject", "exam_score": "Average exam score"})
    st.plotly_chart(fig, use_container_width=True)

left, right = st.columns(2)
with left:
    st.subheader("Attendance vs exam score")
    fig = px.scatter(filtered, x="attendance_pct", y="exam_score", color="department",
                     hover_data=["student_id", "subject"],
                     labels={"attendance_pct": "Attendance (%)", "exam_score": "Exam score"})
    st.plotly_chart(fig, use_container_width=True)
with right:
    st.subheader("Study hours vs exam score")
    fig = px.scatter(filtered, x="study_hours_per_day", y="exam_score", color="subject",
                     hover_data=["student_id", "department"],
                     labels={"study_hours_per_day": "Study hours per day", "exam_score": "Exam score"})
    st.plotly_chart(fig, use_container_width=True)

st.subheader("Data table")
st.dataframe(filtered, use_container_width=True, hide_index=True)
st.download_button("Download filtered data as CSV",
                   data=filtered.to_csv(index=False).encode("utf-8"),
                   file_name="filtered_student_performance.csv",
                   mime="text/csv")

st.subheader("Automatic observations")
top_subject = subject_avg.iloc[0]["subject"]
top_score = subject_avg.iloc[0]["exam_score"]
low_attendance = (filtered["attendance_pct"] < 75).mean() * 100
st.write(f"- **Highest average-scoring subject in the current view:** {top_subject} ({top_score:.1f}/100).")
st.write(f"- **Students below 75% attendance:** {low_attendance:.1f}% of the current view.")
corr = filtered["attendance_pct"].corr(filtered["exam_score"])
if pd.notna(corr):
    st.write(f"- **Attendance and exam score correlation:** {corr:.2f}. Correlation does not prove causation.")

st.info("Portfolio note: This dataset is synthetic demo data, not real student records. Replace it with a permitted dataset before making real-world claims.")
