# Student Performance Analytics Dashboard

A beginner-friendly portfolio project for a Data Analytics internship. It explores synthetic student performance data using Python, Pandas, Plotly, and Streamlit.

## Features
- KPI cards: student count, average exam score, pass rate, average attendance
- Filters for department, subject, and minimum attendance
- Charts for score distribution, average score by subject, attendance vs. score, and study hours vs. score
- Filtered data table and CSV download
- Upload your own CSV using the sidebar
- Automatic observations with a caution that correlation does not prove causation

## Run locally
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Start the app:
   ```bash
   streamlit run app.py
   ```

## Dataset columns
- `student_id`
- `department`
- `subject`
- `attendance_pct`
- `study_hours_per_day`
- `assignment_score`
- `exam_score`

The included CSV contains synthetic demo data. Do not describe it as real institutional data.

## Deploy online
The easiest beginner route is Streamlit Community Cloud:
1. Create a GitHub account and a new public repository.
2. Upload `app.py`, `requirements.txt`, and `student_performance_demo.csv`.
3. Open https://share.streamlit.io/ and sign in with GitHub.
4. Choose the repository, branch, and `app.py` as the main file.
5. Click Deploy. The platform will generate a public app URL after deployment completes.

## Resume-ready description (use after you have run and understood it)
**Student Performance Analytics Dashboard | Python, Pandas, Plotly, Streamlit**
- Built an interactive dashboard to explore student attendance, study habits, assignment scores, and exam performance.
- Added filters, KPI metrics, interactive charts, and CSV export to support exploratory analysis.
- Generated descriptive observations and documented limitations of synthetic data and correlation analysis.

## Interview talking points
- Explain how filters affect the displayed KPIs and charts.
- Explain the pass-rate definition used in this demo (exam score >= 40).
- Discuss why correlation does not imply causation.
- Describe how you would validate, clean, and protect real student data.
